/**
 *
 * @author yohan
 */
public class GraphNode {

    int data;

    public GraphNode(int new_data) {
        this.data = new_data;
    }
}
